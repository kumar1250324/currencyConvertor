import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CurrencyDetailComponent } from './currency-detail/currency-detail.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {
  path: 'currency-convertor',
  component: CurrencyDetailComponent,
},
{
  path: '',
  component: LoginComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

}
