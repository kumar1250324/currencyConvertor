import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {  Router } from '@angular/router';
import { users } from '../config/users.config';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm!: FormGroup;
  validCred:boolean = false;
  constructor(public fb: FormBuilder,private http: HttpClient, private _router : Router) {}

  ngOnInit(): void {
    this.reactiveForm()
  }

  reactiveForm() {
    this.loginForm = this.fb.group({
      username:['',Validators.required],
      password:['',Validators.required]    
    })
  }

  submitForm() {
    if(this.loginForm.controls['username'].valid && this.loginForm.controls['password'].valid){
     let username = this.loginForm.controls['username'].value;
     let password = this.loginForm.controls['password'].value

      let authenticateUser = users.find((u) => u.username === username);
      if(authenticateUser){
        this._router.navigate(["/currency-convertor"])
      }else{
        this.validCred = true;
      }
    }
    
    
  }


}
