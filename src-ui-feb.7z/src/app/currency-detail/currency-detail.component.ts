import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Observable } from 'rxjs';
import { Currency } from '../model/currency.model';

@Component({
  selector: 'app-currency-detail',
  templateUrl: './currency-detail.component.html',
  styleUrls: ['./currency-detail.component.scss']
})
export class CurrencyDetailComponent {

  myForm!: FormGroup;
  baseURL: string = "http://localhost:8080/";
  constructor(public fb: FormBuilder,private http: HttpClient) {}

  ngOnInit(): void {
    this.reactiveForm()
  }

  reactiveForm() {
    this.myForm = this.fb.group({
      fromQuantity:[''],
      toCurrency:[''],
     fromCurrency:[''],
     convertedQuantity:['']
    })
  }

  submitForm() {
    this.myForm.controls['convertedQuantity'].setValue('');
    console.log(this.myForm.value)
    this.checkCurrency(this.myForm.value)
      .subscribe(data => {
        console.log(data.client_sell_amount),
        this.myForm.controls['convertedQuantity'].setValue(data.client_sell_amount);       
      })      
  }

  checkCurrency(currency:Currency): Observable<any> {
    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(currency);
    console.log(body)
    return this.http.post(this.baseURL + 'currency/fetch-rate', body,{'headers':headers})
  }
}
