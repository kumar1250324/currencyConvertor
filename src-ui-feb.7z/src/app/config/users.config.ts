import { User } from "../model/user.model";

export let users = [
    new User(101,"user1","user1","12345"),
    new User(101,"user2","user2","12345"),
]