export class Currency {
    fromQuantity!: String;
    toCurrency!: String;
    fromCurrency!: String;
  }