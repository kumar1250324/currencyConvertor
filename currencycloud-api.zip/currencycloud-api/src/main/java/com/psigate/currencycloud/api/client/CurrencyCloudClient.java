package com.psigate.currencycloud.api.client;


import com.psigate.currencycloud.api.response.RateResponse;
import com.psigate.currencycloud.api.response.Token;
import com.psigate.currencycloud.api.service.TokenService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;

@Service
@Slf4j
public class CurrencyCloudClient {


    @Autowired
    private RestTemplate restTemplate;
    @Autowired
    private TokenService tokenService;
    @Value("${currencycloud.rateservice.url}")
    private String currencyCloudEndPoint;
    private Token token;

    public Object getRates(
            String buyCurrency,
            String sellCurrency,
            String amount,
            String fixedSide) {

        if(token == null || token.getCreatedDateTime().plusMinutes(30).isBefore(LocalDateTime.now())) {
            token  = tokenService.getToken();
        }

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        headers.add("X-Auth-Token", token.getAuthToken());
        StringBuilder params = new  StringBuilder();
        params.append("?buy_currency="+buyCurrency+"&sell_currency="+sellCurrency+"&amount="+amount+"&fixed_side="+fixedSide);
        String url = currencyCloudEndPoint + params.toString();
        ResponseEntity<RateResponse> response = restTemplate.exchange(url, HttpMethod.GET,new HttpEntity<Object>(headers),  RateResponse.class);
        return response.getBody();

    }


}
