package com.psigate.currencycloud.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class RateResponse
{

    @JsonProperty( "settlement_cut_off_time")
    private String settlementCutOffTime;
    @JsonProperty( "currency_pair")
    private String currencyPair;

    @JsonProperty("client_buy_currency")
    private String clientBuyCurrency;

    @JsonProperty( "client_sell_currency")
    private String clientSellCurrency;

    @JsonProperty( "client_buy_amount")
    private String clientBuyAmount;

    @JsonProperty( "client_sell_amount")
    private String clientSellAmount;

    @JsonProperty( "fixed_side")
    private String fixedSide;

    @JsonProperty( "client_rate")
    private String clientRate;

    @JsonProperty(  "partner_rate")
    private String partnerRate;

    @JsonProperty( "core_rate")
    private String coreRate;

    @JsonProperty(  "deposit_required")
    private Boolean depositRequired;

    @JsonProperty(  "deposit_amount")
    private String depositAmount;

    @JsonProperty(  "deposit_currency")
    private String depositCurrency;

    @JsonProperty("mid_market_rate")
    private String midMarketRate;


}

