package com.psigate.currencycloud.api.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Builder
@AllArgsConstructor
public class TokenRequest {
    @JsonProperty("api_key")
    private String apikey;
    @JsonProperty("login_id")
    private String loginId;

}
