package com.psigate.currencycloud.api.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class RateRequest {

    @NotNull
    private Currency fromCurrency;
    @NotNull
    private Currency toCurrency;
    @NotBlank
    private String fromQuantity;


    @AllArgsConstructor
    @Getter
    public static enum Currency {
      CAD("CAD"),
      GBP("GBP"),
      EUR("EUR");

      private String currencyCode;


    }
}
