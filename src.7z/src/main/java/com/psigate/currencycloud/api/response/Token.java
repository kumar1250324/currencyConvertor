package com.psigate.currencycloud.api.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.time.LocalDateTime;

@NoArgsConstructor
@Data
public class Token {
    @JsonProperty("auth_token")
    private String authToken;
    private LocalDateTime createdDateTime = LocalDateTime.now();
}
