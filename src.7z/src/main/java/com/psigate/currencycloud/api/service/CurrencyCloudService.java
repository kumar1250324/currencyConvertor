package com.psigate.currencycloud.api.service;

import com.psigate.currencycloud.api.client.CurrencyCloudClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CurrencyCloudService {


    @Autowired
    private CurrencyCloudClient currencyCloudClient;

    public Object getRate(  String buyCurrency,
                            String sellCurrency,
                            String amount,
                            String fixedSide
    ) {
    	System.out.println("buycurrency "+buyCurrency+" sellC "+sellCurrency+" amount "+ amount + " fixedSide "+ fixedSide);
        Object response= currencyCloudClient.getRates( buyCurrency, sellCurrency, amount, fixedSide);
       log.info("response ...{}",response);
        return response;
    }
}
