package com.psigate.currencycloud.api.rest;

import com.psigate.currencycloud.api.request.RateRequest;
import com.psigate.currencycloud.api.response.ErrorResponse;
import com.psigate.currencycloud.api.service.CurrencyCloudService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/currency")
@Slf4j
@CrossOrigin
public class CurrencyConversionRateController {



    @Autowired
    private CurrencyCloudService currencyCloudService;

    @PostMapping("/fetch-rate")
    public ResponseEntity<Object> getConversionRate(@Valid  @RequestBody RateRequest rateRequest)
    {
        log.info("invoking fetch-rate {}", rateRequest);
        try {

            return ResponseEntity.ok(currencyCloudService.getRate(rateRequest.getToCurrency().getCurrencyCode(),
                    rateRequest.getFromCurrency().getCurrencyCode(),
                    rateRequest.getFromQuantity(), "buy"));
        }
        catch(Exception e)
        {
            log.error("Error in /fetch-rate", e);
            return ResponseEntity.internalServerError().body(ErrorResponse.builder().errorCode(500).errorMsg("Internal Server Error").build());
        }




    }
}
