package com.psigate.currencycloud.api.service;

import com.psigate.currencycloud.api.request.TokenRequest;
import com.psigate.currencycloud.api.response.Token;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j

@EnableConfigurationProperties
@ConfigurationProperties
public class TokenService {
  @Value("${currencycloud.auth.userid}")
    private String userId;
    @Value("${currencycloud.auth.apikey}")
    private String apiKey;
    @Value("${currencycloud.auth.url}")
    private String authUrl;
    @Autowired
    private RestTemplate restTemplate;


    public Token getToken() {        
        TokenRequest tokenRequest = TokenRequest.builder().apikey(apiKey).loginId(userId).build();        
        Token token =  restTemplate.postForObject(authUrl, tokenRequest, Token.class);
        return token;

    }

}
